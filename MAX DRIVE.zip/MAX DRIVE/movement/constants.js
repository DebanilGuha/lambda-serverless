const MOVEMENT_TYPES=[
    'PickUpInitiated',
    'CheckInInitiated',
    'CheckOutInitiated',
    'TransferInitiated',
    'TransferAccepted'
];

module.exports={MOVEMENT_TYPES}